"""Image analysis for auto-selection."""
from .auto_select import AutoSelector, select_method
